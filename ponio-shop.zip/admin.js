let products = JSON.parse(localStorage.getItem("products")) || [];

function saveProducts() {
  localStorage.setItem("products", JSON.stringify(products));
}

function renderAdminProducts() {
  const list = document.getElementById("admin-product-list");
  list.innerHTML = "";

  if (products.length === 0) {
    list.innerHTML = "<p>არ არის დამატებული პროდუქტი</p>";
    return;
  }

  products.forEach((product, index) => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = `
      <img src="${product.image}" width="60" height="60">
      <div class="product-details">
        <h3>${product.name} (${product.category})</h3>
        <p>${product.description}</p>
        <span>ფასი: ${product.price} ₾</span><br>
        <button onclick="deleteProduct(${index})">წაშლა</button>
      </div>
    `;
    list.appendChild(div);
  });
}

function deleteProduct(index) {
  if (confirm("ნამდვილად გსურს წაშლა?")) {
    products.splice(index, 1);
    saveProducts();
    renderAdminProducts();
  }
}

document.getElementById("add-form").addEventListener("submit", function (e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const description = document.getElementById("description").value.trim();
  const price = parseFloat(document.getElementById("price").value);
  const image = document.getElementById("image").value.trim();
  const category = document.getElementById("category").value.trim();

  if (!name || !description || isNaN(price) || !image || !category) {
    alert("შეავსე ყველა ველი!");
    return;
  }

  const newProduct = { id: Date.now(), name, description, price, image, category };
  products.push(newProduct);
  saveProducts();
  renderAdminProducts();

  document.getElementById("add-form").reset();
});

renderAdminProducts();
