const stripePublicKey = "pk_test_შენი_გასაღები"; // შეცვალე შენი Stripe Public Key-ით

let products = JSON.parse(localStorage.getItem("products")) || [];
let cart = JSON.parse(localStorage.getItem("cart")) || [];

function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

function renderProducts() {
  const productList = document.getElementById("product-list");
  productList.innerHTML = "";
  products.forEach(product => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = `
      <img src="\${product.image}" alt="\${product.name}" />
      <div class="product-details">
        <h3>\${product.name}</h3>
        <p>\${product.description}</p>
        <span>ფასი: \${product.price} ₾</span>
        <button onclick="addToCart(\${product.id})">დამატება</button>
      </div>
    `;
    productList.appendChild(div);
  });
}

function renderCart() {
  const cartItems = document.getElementById("cart-items");
  const totalDisplay = document.getElementById("total");
  cartItems.innerHTML = "";

  if (cart.length === 0) {
    cartItems.innerHTML = "<p>კალათა ცარიელია</p>";
    totalDisplay.textContent = "";
    return;
  }

  let total = 0;
  cart.forEach((item, index) => {
    total += item.price;
    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = \`
      <span>\${item.name} - \${item.price} ₾</span>
      <button onclick="removeFromCart(\${index})">წაშლა</button>
    \`;
    cartItems.appendChild(div);
  });

  totalDisplay.textContent = \`ჯამი: \${total} ₾\`;
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  saveCart();
  renderCart();
}

function removeFromCart(index) {
  cart.splice(index, 1);
  saveCart();
  renderCart();
}

document.getElementById("checkout-button").addEventListener("click", () => {
  if (cart.length === 0) {
    alert("გთხოვთ, დაამატეთ პროდუქტი კალათაში.");
    return;
  }

  // ლაინელთს Stripe-სთვის
  const lineItems = cart.map(product => ({
    price_data: {
      currency: "gel",
      product_data: {
        name: product.name,
        description: product.description,
      },
      unit_amount: product.price * 100,
    },
    quantity: 1
  }));

  fetch("https://ponio-server.onrender.com/create-checkout-session", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ items: lineItems })
  })
    .then(res => res.json())
    .then(data => {
      return Stripe(stripePublicKey).redirectToCheckout({ sessionId: data.sessionId });
    })
    .catch(err => console.error("Error:", err));
});

renderProducts();
renderCart();
